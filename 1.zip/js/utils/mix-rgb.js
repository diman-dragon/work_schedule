/* utils/mix-rgb.js
 * Автоматически выделено из монолитного index.html при разбиении на модули.
 */
function mixRgb(c1, c2, t){
  return {
    r: Math.round(c1.r + (c2.r - c1.r) * t),
    g: Math.round(c1.g + (c2.g - c1.g) * t),
    b: Math.round(c1.b + (c2.b - c1.b) * t)
  };
}
